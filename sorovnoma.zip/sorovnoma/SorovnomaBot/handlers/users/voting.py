import random
from pathlib import Path
import urllib.request

import pyfiglet
from aiogram import types
from aiogram.dispatcher.filters.builtin import Command
from aiogram.dispatcher import FSMContext
from aiogram.types import InputFile, Message, ReplyKeyboardRemove

from keyboards.inline.channels_list import captcha_keyboards
from keyboards.inline.sorovnoma import sorovnoma_details
from loader import dp, bot

from keyboards.default.contact_button import keyboard
from keyboards.default.admin_menu import admin_menu

from handlers.users.utilities import create_admin, create_sorovnoma, voting_sorovnoma, get_cahnnels, verify_human, \
    get_sorovnoma_details, check_human, joined_user

from keyboards.inline.required_channel import channel_offer, required_channel

from data.config import URL

from data.config import BOT_URL


@dp.callback_query_handler(state='get_variant')
async def callback_handler(query: types.CallbackQuery, state: FSMContext):
    answer_data = query.data
    user_id = query.from_user.id
    result = await get_cahnnels(answer_data)
    await state.update_data({
        "voting_sorovnoma_id": answer_data
    })
    if result != []:
        await state.update_data({
            "channels": [i['name'] for i in result]
        })
        await bot.send_message(user_id, "Quyidagi kanallarga a'zo bo'ling va Tekshirish tugmasini bosing.",
                               reply_markup=required_channel(result))
        await state.set_state('check_member')
    else:
        result = await check_human(user_id)
        if result['msg']:
            response = await voting_sorovnoma(answer_data, user_id)
            if response['msg'] == "Success":
                await bot.send_message(user_id, f"Siz <b>{response['variant']}</b> ga ovoz berdingiz.")
            else:
                await bot.send_message(user_id, f"Siz avval ovoz berib bo'lgansiz")
        else:
            number1 = random.randint(0, 20)
            number2 = random.randint(11, 50)

            result = number2 + number1
            await state.update_data({"result": result})
            variant_list = []
            variant_list.append(result)
            result1 = random.randint(result + 2, 90)
            flag = True
            while flag:
                if result1 not in variant_list:
                    variant_list.append(result1)
                    flag = False
                else:
                    result1 = random.randint(result + 2, 90)
            result2 = random.randint(11, 50)
            flag2 = True
            while flag2:
                if result2 not in variant_list:
                    variant_list.append(result2)
                    flag2 = False
                else:
                    result2 = random.randint(result + 2, 90)
            text = f"To'g'ri javobni tanlang:\n<b>{number2} + {number1} = </b>"
            await bot.send_message(user_id, text, reply_markup=captcha_keyboards(variant_list))
            await state.set_state('captcha')

    await query.message.delete()


async def check_sub_channels(channels, user_id):
    for channel in channels:
        try:
            chat_member = await bot.get_chat_member(chat_id='@' + channel, user_id=user_id)
            if chat_member['status'] == 'left':
                return False
        except:
            return False
    return True


@dp.callback_query_handler(state='check_member')
async def check_member(query: types.CallbackQuery, state: FSMContext):
    answer_data = query.data
    user_id = query.from_user.id
    if answer_data == "checking":
        state_data = await state.get_data()
        if await check_sub_channels(state_data.get('channels'), user_id):
            id = state_data.get('sorovnoma_id')
            await joined_user(id)
            result = await check_human(user_id)
            if result['msg']:
                sorovnoma_id = state_data.get('voting_sorovnoma_id')
                response = await voting_sorovnoma(sorovnoma_id, user_id)
                if response['msg'] == "Success":
                    await bot.send_message(user_id, f"Siz <b>{response['variant']}</b> ga ovoz berdingiz.")
                else:
                    await bot.send_message(user_id, f"Siz avval ovoz berib bo'lgansiz")
            else:
                number1 = random.randint(0, 20)
                number2 = random.randint(11, 50)

                result = number2 + number1
                await state.update_data({"result": result})
                variant_list = []
                variant_list.append(result)
                result1 = random.randint(result + 2, 90)
                flag = True
                while flag:
                    if result1 not in variant_list:
                        variant_list.append(result1)
                        flag = False
                    else:
                        result1 = random.randint(result + 2, 90)
                result2 = random.randint(11, 50)
                flag2 = True
                while flag2:
                    if result2 not in variant_list:
                        variant_list.append(result2)
                        flag2 = False
                    else:
                        result2 = random.randint(result + 2, 90)
                text = f"To'g'ri javobni tanlang:\n<b>{number2} + {number1} = </b>"
                await bot.send_message(user_id, text, reply_markup=captcha_keyboards(variant_list))
                await state.set_state('captcha')
            await query.message.delete()


@dp.callback_query_handler(state='captcha')
async def callback_handler(query: types.CallbackQuery, state: FSMContext):
    user_id = query.from_user.id
    answer = query.data
    state_data = await state.get_data()
    if int(answer) == int(state_data.get('result')):
        await verify_human(user_id)
        sorovnoma_id = state_data.get('voting_sorovnoma_id')
        response = await voting_sorovnoma(sorovnoma_id, user_id)
        if response['msg'] == "Success":
            await bot.send_message(user_id, f"Siz <b>{response['variant']}</b> ga ovoz berdingiz.")
        else:
            await bot.send_message(user_id, f"Siz avval ovoz berib bo'lgansiz")
    else:
        number1 = random.randint(0, 20)
        number2 = random.randint(11, 50)

        result = number2 + number1
        await state.update_data({"result": result})
        variant_list = []
        variant_list.append(result)
        result1 = random.randint(result + 2, 90)
        flag = True
        while flag:
            if result1 not in variant_list:
                variant_list.append(result1)
                flag = False
            else:
                result1 = random.randint(result + 2, 90)
        result2 = random.randint(11, 50)
        flag2 = True
        while flag2:
            if result2 not in variant_list:
                variant_list.append(result2)
                flag2 = False
            else:
                result2 = random.randint(result + 2, 90)
        text = f"To'g'ri javobni tanlang:\n<b>{number2} + {number1} = </b>"
        await bot.send_message(user_id, text, reply_markup=captcha_keyboards(variant_list))
        await state.set_state('captcha')

    await query.message.delete()


@dp.callback_query_handler(state='voting_variant')
async def voting_callback(query: types.CallbackQuery, state: FSMContext):
    user_id = query.from_user.id
    answer = query.data
    response = await voting_sorovnoma(answer, user_id)
    if response['msg'] == "Success":
        await bot.send_message(user_id, f"Siz <b>{response['variant']}</b> ga ovoz berdingiz.")
    else:
        await bot.send_message(user_id, "Siz avval ovoz berib bo'lgansiz")
    await query.message.delete()
