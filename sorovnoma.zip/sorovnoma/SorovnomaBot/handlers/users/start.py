from pathlib import Path
import urllib.request
from aiogram import types
from aiogram.dispatcher.filters.builtin import Command
from aiogram.dispatcher import FSMContext
from aiogram.types import InputFile, Message, ReplyKeyboardRemove

from keyboards.inline.sorovnoma import sorovnoma_details
from loader import dp, bot

from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart

from data.config import URL, BOT_URL
from loader import dp

from handlers.users.utilities import create_user, get_sorovnoma_details

from keyboards.default.admin_menu import admin_menu


@dp.message_handler(CommandStart(), state='*')
async def bot_start(message: types.Message, state: FSMContext):
    full_name = message.from_user.full_name
    tg_id = message.from_id
    result = await create_user(full_name, tg_id)
    if result['status'] == 402:
        if result['role']:
            await message.answer(f"Xush kelibsiz, {message.from_user.full_name}!", reply_markup=admin_menu)
        else:
            await message.answer(f"Xush kelibsiz, {message.from_user.full_name}!")
    else:
        await message.answer(f"Xush kelibsiz, {message.from_user.full_name}!")
    args = message.get_args()
    if args:
        await state.update_data({
            "sorovnoma_id": args
        })
        sorovnoma = await get_sorovnoma_details(args)
        image_url = URL + sorovnoma['image']
        urllib.request.urlretrieve(image_url, f"photos/stamp-image-{sorovnoma['id']}.jpg")
        photo_file = InputFile(path_or_bytesio=f"photos/stamp-image-{sorovnoma['id']}.jpg")
        caption = sorovnoma['description']
        await bot.send_photo(tg_id, photo_file, caption, reply_markup=sorovnoma_details(sorovnoma['variants']),
                             parse_mode='html')
        await state.set_state("get_variant")
