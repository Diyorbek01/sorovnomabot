from pathlib import Path
import urllib.request
from aiogram import types
from aiogram.dispatcher.filters.builtin import Command
from aiogram.dispatcher import FSMContext
from aiogram.types import InputFile, Message, ReplyKeyboardRemove

from keyboards.inline.channels_list import channel_kb_list
from loader import dp, bot

from keyboards.default.contact_button import keyboard
from keyboards.default.admin_menu import admin_menu

from handlers.users.utilities import get_sorovnoma, plan_channel_users

from keyboards.inline.required_channel import channel_offer

from data.config import URL

from data.config import BOT_URL

from keyboards.inline.sorovnoma import sorovnoma_helper

from handlers.users.utilities import cancel_sorovnoma, channel_list


@dp.message_handler(text="Majburiy kanallar", state='*')
async def required_channels(message: types.Message, state: FSMContext):
    user_id = message.from_id
    required_channel_list = await channel_list(user_id)
    if required_channel_list == []:
        await bot.send_message(user_id, "Majburiy kanallar hozircha mavjud emas.")
    else:
        await bot.send_message(user_id, "Kanallar ro'yxati.\n<i>Reja qo'shish uchun tanlang.</i>",
                               reply_markup=channel_kb_list(required_channel_list), parse_mode='html')
        await state.set_state('plan_channel')


@dp.callback_query_handler(state='plan_channel')
async def inline_kb_answer(query: types.CallbackQuery, state: FSMContext):
    answer_data = query.data
    user_id = query.from_user.id
    # data['tg_id'] = answer_data
    await state.update_data({
        'tg_id': answer_data
    })
    await bot.send_message(user_id, "Maximal qo'shilishi kerak bo'lgan foydalnuvchilar sonini kiriting:")
    await state.set_state('get_number_users')
    await query.message.delete()


@dp.message_handler(state='get_number_users')
async def get_users_number(message: types.Message, state: FSMContext):
    answer_data = message.text
    user_id = message.from_user.id
    if answer_data.isdigit():
        state_data = await state.get_data()
        await plan_channel_users(tg_id=state_data.get('tg_id'), number=answer_data)
        await bot.send_message(user_id, "Muvaffaqiyatli reja qo'shildi")
        await state.finish()
    else:
        await bot.send_message(user_id, "Iltimos raqamda kiriting")
        await state.set_state('get_number_users')
