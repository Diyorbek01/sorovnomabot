import os

import requests as requests

from data.config import URL, TOKEN


async def create_admin(full_name, tg_id, phone_number):
    url = f"{URL}/api/v1/sorovnoma/create_admin/"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    data = {
        'full_name': full_name,
        'tg_id': tg_id,
        'phone_number': phone_number,
    }
    response = requests.request("POST", url, data=data, headers=headers)
    return response.status_code


async def channel_list(tg_id):
    url = f"{URL}/api/v1/required-channel/get_channels?tg_id={tg_id}"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }

    response = requests.request("GET", url, headers=headers)
    return response.json()


async def create_user(full_name, tg_id):
    url = f"{URL}/api/v1/sorovnoma/create_admin/"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    data = {
        'full_name': full_name,
        'tg_id': tg_id,
        'user': True,
    }
    response = requests.request("POST", url, data=data, headers=headers)
    return response.json()


async def plan_channel_users(tg_id, number):
    url = f"{URL}/api/v1/required-channel/set_plan_channels/"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    data = {
        'channel_id': tg_id,
        'number': number,
    }
    response = requests.request("POST", url, data=data, headers=headers)
    return response.json()


async def create_sorovnoma(image, description, variants, date, channels, tg_id):
    url = f"{URL}/api/v1/sorovnoma/create_sorovnoma/"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    data = {
        'description': description,
        'variants': variants,
        'date': date,
        'channels': channels,
        'user_id': tg_id
    }
    files = [
        (
            'image',
            (
                'sorovnoma.jpeg',
                open(f'{os.path.abspath(image.name)}', 'rb'),
                'image/jpeg'
            )
        )
    ]
    response = requests.request("POST", url, data=data, headers=headers, files=files)
    return response.json()


async def get_sorovnoma(tg_id):
    url = f"{URL}/api/v1/sorovnoma/get_sorovnoma/?tg_id={tg_id}"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    response = requests.request("GET", url, headers=headers)
    return response.json()


async def get_sorovnoma_details(tg_id):
    url = f"{URL}/api/v1/sorovnoma/get_details/?id={tg_id}"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    response = requests.request("GET", url, headers=headers)
    return response.json()


async def cancel_sorovnoma(id):
    url = f"{URL}/api/v1/sorovnoma/cancel_sorovnoma/?id={id}"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    response = requests.request("GET", url, headers=headers)
    return response.json()


async def voting_sorovnoma(variant, tg_id):
    url = f"{URL}/api/v1/sorovnoma/voting/?variant={variant}&tg_id={tg_id}"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    response = requests.request("GET", url, headers=headers)
    return response.json()


async def get_cahnnels(variant):
    url = f"{URL}/api/v1/required-channel/get_channels_variant?variant={variant}"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    response = requests.request("GET", url, headers=headers)
    return response.json()


async def verify_human(tg_id):
    url = f"{URL}/api/v1/sorovnoma/verify_human/?tg_id={tg_id}"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    response = requests.request("GET", url, headers=headers)
    return response.status_code


async def check_human(tg_id):
    url = f"{URL}/api/v1/sorovnoma/check_human/?tg_id={tg_id}"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    response = requests.request("GET", url, headers=headers)
    return response.json()


async def joined_user(id):
    url = f"{URL}/api/v1/required-channel/joined_user?id={id}"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    response = requests.request("GET", url, headers=headers)
    return response.json()


async def get_all_users():
    url = f"{URL}/api/v1/required-channel/get_all_users"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    response = requests.request("GET", url, headers=headers)
    return response.json()


async def update_deadline(id, day):
    url = f"{URL}/api/v1/sorovnoma/update_deadline/"

    headers = {
        "Authorization": f"Token {TOKEN}"
    }
    data = {
        "id": id,
        "day": day
    }
    response = requests.request("POST", url, headers=headers, data=data)
    return response.status_code
