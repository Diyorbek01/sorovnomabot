from pathlib import Path
import urllib.request
from aiogram import types
from aiogram.dispatcher.filters.builtin import Command
from aiogram.dispatcher import FSMContext
from aiogram.types import InputFile, Message, ReplyKeyboardRemove
from loader import dp, bot

from keyboards.default.contact_button import keyboard
from keyboards.default.admin_menu import admin_menu

from handlers.users.utilities import get_sorovnoma, update_deadline

from keyboards.inline.required_channel import channel_offer

from data.config import URL

from data.config import BOT_URL

from keyboards.inline.sorovnoma import sorovnoma_helper

from handlers.users.utilities import cancel_sorovnoma


@dp.message_handler(text="So'rovnomalar", state='*')
async def show_sorovnoma(message: types.Message, state: FSMContext):
    user_id = message.from_id
    response = await get_sorovnoma(user_id)
    if response == []:
        await bot.send_message(user_id, "Kechirasiz, so'rovnomalar mavjud emas")
    else:
        for res in response:
            date = res['deadline'].replace('T', ' ')
            date = date.replace('Z', '')
            image_url = URL + res['image']
            urllib.request.urlretrieve(image_url, f"photos/sorovnoma-image-{res['id']}.jpg")
            photo_file = InputFile(path_or_bytesio=f"photos/sorovnoma-image-{res['id']}.jpg")
            link = f'<a href="{BOT_URL[0]}{res["id"]}">Ovoz berish</a>'
            caption = res['description'] + '\n' + link + '\n\n' + '<i> Tugash vaqti:</i>' + f" <b>{date}</b>\n" \
                                                                                            f"Ovozlar soni: {res['number_of_votes']}"
            await bot.send_photo(user_id, photo_file, caption, reply_markup=sorovnoma_helper(res['id']),
                                 parse_mode='html')

        await state.set_state("details")


@dp.callback_query_handler(state='details')
async def callback_handler(query: types.CallbackQuery, state: FSMContext):
    answer_data = query.data
    user_id = query.from_user.id
    status = answer_data.split('-')[0]
    id = answer_data.split('-')[1]
    if status == 'cancel':
        await cancel_sorovnoma(id)
        await bot.send_message(user_id, "So'rovnoma tugatildi")
        await query.message.delete()
        await state.finish()

    elif status == 'deadline':
        await state.update_data({"changing_sorovnoma_id": id})
        await bot.send_message(user_id,
                               "Necha kunga o'zgartirmoqchisiz?\nIxitiyoriy son kiritishingiz mumkin.\n--------------------\n<b>-1</b> -- 1 kunga kamaytiradi\n<b>1</b> -- 1 kunga uzaytiradi")
        await state.set_state("change_deadline")


@dp.message_handler(state='change_deadline')
async def set_new_date(message: types.Message, state: FSMContext):
    user_id = message.from_id
    state_data = await state.get_data()
    id = state_data.get('changing_sorovnoma_id')
    data = message.text
    response = await update_deadline(id, data)
    if response == 200:
        await bot.send_message(user_id, "Muvuffaqiyatli yangilandi!")
    else:
        await bot.send_message(user_id, "Xatolik yuz berdi!")
    await state.finish()
