import asyncio
from aiogram.types import ContentType, Message
from aiogram import types
from aiogram.dispatcher import FSMContext
from data.config import ADMINS
from handlers.users.utilities import get_all_users
from loader import dp, bot


@dp.message_handler(text="/reklama", user_id=ADMINS)
async def send_ad_to_all(message: types.Message, state: FSMContext):
    await bot.send_message(chat_id=message.from_user.id, text="Reklama postini yuboring")
    await state.set_state('get_ads')


@dp.message_handler(state='get_ads', content_types=ContentType.ANY)
async def recieve_ads(message: types.Message, state: FSMContext):
    users = await get_all_users()
    message_id = message.message_id
    user_id = message.from_user.id
    total_users = 0
    for user in users:
        try:
            await bot.copy_message(chat_id=user, from_chat_id=user_id, message_id=message_id)
            total_users += 1
            await asyncio.sleep(0.05)
        except Exception as e:
            continue
    await bot.send_message(user_id, f"Reklama {total_users} ta foydalanuvchilarga yuborildi")
    await state.finish()
