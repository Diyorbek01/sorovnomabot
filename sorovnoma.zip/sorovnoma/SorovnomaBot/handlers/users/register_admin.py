from aiogram import types
from aiogram.dispatcher.filters.builtin import Command
from aiogram.dispatcher import FSMContext
from aiogram.types import InputFile, Message, ReplyKeyboardRemove
from loader import dp

from keyboards.default.contact_button import keyboard
from keyboards.default.admin_menu import admin_menu

from handlers.users.utilities import create_admin

data = {
    'phone_number': None,
    'full_name': None,
    'user_id': None,
}


@dp.message_handler(Command('registration'), state='*')
async def registration_admin(message: types.Message, state: FSMContext):
    text = "Telefon raqamingizni yuboring"

    await message.answer(text, reply_markup=keyboard)
    await state.set_state("phone_number")


@dp.message_handler(content_types=['contact', 'text'], state='phone_number')
async def get_contact(message: Message, state: FSMContext):
    if message.contact is not None:
        phone_number = message.contact.phone_number
        data['phone_number'] = phone_number
    else:
        phone_number = message.text
        data['phone_number'] = phone_number

    await message.reply("Yaxshi, endi ism familyangizni yuboring\nMisol uchun: <i>Diyorbek Yuldashev</i>",
                        parse_mode='html')
    await state.set_state('full_name')


@dp.message_handler(state='full_name')
async def get_fullname(message: Message, state: FSMContext):
    text = message.text
    user_id = message.from_id
    data['full_name'] = text
    data['user_id'] = user_id
    result = await create_admin(
        full_name=data['full_name'],
        tg_id=data['user_id'],
        phone_number=data['phone_number']
    )
    if result == 201:
        await message.reply("Xush kelibsiz", reply_markup=admin_menu)
    else:
        await message.reply("Xatolik yuz berdi, qaytadan harakat qilib ko'ring")
    await state.finish()
