from pathlib import Path
import urllib.request
from aiogram import types
from aiogram.dispatcher.filters.builtin import Command
from aiogram.dispatcher import FSMContext
from aiogram.types import InputFile, Message, ReplyKeyboardRemove
from loader import dp, bot

from keyboards.default.contact_button import keyboard
from keyboards.default.admin_menu import admin_menu

from handlers.users.utilities import create_admin, create_sorovnoma

from keyboards.inline.required_channel import channel_offer

from data.config import URL

from data.config import BOT_URL

download_path = Path().joinpath("downloads", "documents")
download_path.mkdir(parents=True, exist_ok=True)

data = {
    'photo': None,
    'description': None,
    'variants': None,
    'date': None,
    'channels': None,
    'tg_id': None,
}


@dp.message_handler(text="So'rovnoma yaratish", state='*')
async def start_create_sorovnoma(message: types.Message, state: FSMContext):
    text = "So'rovnoma uchun ixtiyoriy rasm yuboring"

    await message.answer(text)
    await state.set_state("photo")


@dp.message_handler(content_types='photo', state='photo')
async def photo_handler(message: Message, state: FSMContext):
    photo = await message.photo[-1].download(destination=download_path)
    await message.answer("So'rovnoma uchun tafsilot yozing:")
    data['photo'] = photo
    await state.update_data({'photo': photo})
    await state.set_state('description')


@dp.message_handler(state='description')
async def description(message: Message, state: FSMContext):
    text = message.text
    data['description'] = text
    await state.update_data({'description': text})
    await message.answer("So'rovnoma necha kun davom etadi?\n"
                         "<i>Raqamda kiriting</i>")
    await state.set_state('date')


@dp.message_handler(state='date')
async def description(message: Message, state: FSMContext):
    text = message.text
    if text.isdigit():
        data['date'] = text
        await state.update_data({'date': text})
        await message.answer("Variantlarni kiriting\n<i>Misol: <b>1-maktab, 2-maktab, 3-maktab</b></i>")
        await state.set_state('variants')
    else:
        await message.answer("Xatolik mavjud. Iltimos raqamda kiriting")
        await state.set_state('date')


@dp.message_handler(state='variants')
async def description(message: Message, state: FSMContext):
    text = message.text
    data['variants'] = text
    await state.update_data({'variants': text})
    await message.answer("Majburiy kanal qo'shasizmi?", reply_markup=channel_offer())
    await state.set_state('channel_offer')


@dp.callback_query_handler(state='channel_offer')
async def inline_kb_answer_callback_handler(query: types.CallbackQuery, state: FSMContext):
    answer_data = query.data
    user_id = query.from_user.id
    if answer_data == 'yes':
        await bot.send_message(
            user_id,
            "Kanal username ni yuboring.\nKo'pi bilan 2 ta qabul qilinadi.\n<i>Misol: example_1, example_2</i>",
            parse_mode='html'
        )
        await state.set_state("add_channel")
    else:
        # state_data = await state.get_data()
        result = await create_sorovnoma(
            data.get('photo'),
            data.get('description'),
            data.get('variants'),
            data.get('date'),
            data.get('channels'),
            user_id
        )
        if result['status'] == 201:
            image_url = URL + result['image']
            urllib.request.urlretrieve(image_url, f"photos/stamp-image-{result['id']}.jpg")
            photo_file = InputFile(path_or_bytesio=f"photos/stamp-image-{result['id']}.jpg")
            link = f'<a href="{BOT_URL[0]}{result["id"]}">Ovoz berish</a>'
            caption = result['description'] + '\n' + link
            await bot.send_photo(user_id, photo_file, caption, reply_markup=admin_menu, parse_mode='html')
        else:
            await bot.send_message(user_id, "❌ So'rovnoma yaratishda xatolik yuz berdi!", reply_markup=admin_menu
                                   )
            await state.finish()

    await query.message.delete()


@dp.message_handler(state='add_channel')
async def add_channel(message: Message, state: FSMContext):
    text = message.text
    user_id = message.from_id

    if len(text.split(',')) < 3:
        data['channels'] = text
        # state_data = await state.get_data()
        await state.update_data({'channels': text})
        result = await create_sorovnoma(
            data.get('photo'),
            data.get('description'),
            data.get('variants'),
            data.get('date'),
            data.get('channels'),
            user_id
        )
        if result['status'] == 201:
            image_url = URL + result['image']
            urllib.request.urlretrieve(image_url, f"photos/sorovnoma-image-{result['id']}.jpg")
            photo_file = InputFile(path_or_bytesio=f"photos/sorovnoma-image-{result['id']}.jpg")
            link = f'<a href="{BOT_URL[0]}{result["id"]}">Ovoz berish</a>'
            caption = result['description'] + '\n' + link
            await bot.send_photo(user_id, photo_file, caption, reply_markup=admin_menu, parse_mode='html')
        else:
            await bot.send_message(user_id, "❌ So'rovnoma yaratishda xatolik yuz berdi!", reply_markup=admin_menu
                                   )
        await state.finish()
    else:
        await bot.send_message(user_id, "2 tadan oshiqcha kanal qabul qilinmaydi")
        await state.set_state("add_channel")
