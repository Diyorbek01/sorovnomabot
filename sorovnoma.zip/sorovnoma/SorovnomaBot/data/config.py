from environs import Env

# environs kutubxonasidan foydalanish
env = Env()
env.read_env()

# .env fayl ichidan quyidagilarni o'qiymiz
BOT_TOKEN = env.str("BOT_TOKEN")  # Bot toekn
TOKEN = env.str("TOKEN")  # Bot toekn
URL = env.str("URL")  # Domein
ADMINS = env.list("ADMINS")  # adminlar ro'yxati
BOT_URL = env.list("BOT_URL")  # adminlar ro'yxati
IP = env.str("ip")  # Xosting ip manzili
