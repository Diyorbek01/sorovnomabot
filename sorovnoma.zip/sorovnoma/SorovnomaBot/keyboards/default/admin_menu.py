from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

admin_menu = ReplyKeyboardMarkup(
    resize_keyboard=False,
    one_time_keyboard=True,
    keyboard=[
        [
            KeyboardButton(
                text="So'rovnoma yaratish"
            )
        ],
        [
            KeyboardButton(
                text="So'rovnomalar"
            )
        ],
        [
            KeyboardButton(
                text="Majburiy kanallar"
            )
        ],
    ])
