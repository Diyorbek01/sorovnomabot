import random

import requests
from aiogram import types
from aiogram.dispatcher.filters import state
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def channel_kb_list(data):
    keyboard_markup = types.InlineKeyboardMarkup(row_width=3)

    for i in data:
        tg_id = i['username']
        joined_users = i['joined_users']
        planed_users = int(int(i['planed_users']) / int(i['id']))
        text = f'{tg_id} | {joined_users}/{planed_users}'
        keyboard_markup.add(
            types.InlineKeyboardButton(text=text, callback_data=tg_id),
        )
    return keyboard_markup


def captcha_keyboards(variants):
    keyboard_markup = types.InlineKeyboardMarkup(row_width=3)
    random.shuffle(variants)
    for i in variants:
        keyboard_markup.add(
            types.InlineKeyboardButton(text=i, callback_data=i),
        )
    return keyboard_markup
