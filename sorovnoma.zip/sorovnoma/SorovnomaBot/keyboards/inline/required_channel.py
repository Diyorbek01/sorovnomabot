import requests
from aiogram import types
from aiogram.dispatcher.filters import state
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def channel_offer():
    rate = InlineKeyboardMarkup(
        row_width=2,
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅Ha", callback_data='yes'),
                InlineKeyboardButton(text="❌Yo'q", callback_data="no"),
            ]
        ])
    return rate


def required_channel(data):
    keyboard_markup = types.InlineKeyboardMarkup(row_width=3)

    for i in data:
        keyboard_markup.add(
            types.InlineKeyboardButton(text=i['name'], url=f"https://t.me/{i['name']}"),
        )
    keyboard_markup.add(types.InlineKeyboardButton(text="Tekshirish", callback_data='checking'))
    return keyboard_markup
