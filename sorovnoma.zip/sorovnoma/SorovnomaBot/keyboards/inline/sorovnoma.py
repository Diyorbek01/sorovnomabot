import requests
from aiogram import types
from aiogram.dispatcher.filters import state
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from data.config import URL


def sorovnoma_helper(id):
    rate = InlineKeyboardMarkup(
        row_width=2,
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Tugatish ⭕️", callback_data=f'cancel-{id}'),
                InlineKeyboardButton(text="️Sanani tahrirlash", callback_data=f'deadline-{id}'),
                InlineKeyboardButton(text="Statistika 📊", url=f"{URL}/chart/{id}"),
            ]
        ])
    return rate


def sorovnoma_details(data):
    keyboard_markup = types.InlineKeyboardMarkup(row_width=3)

    for i in data:
        id = i['id']
        text = f"{i['name']} | {i['number_votes']}"
        keyboard_markup.add(
            types.InlineKeyboardButton(text=text, callback_data=id),
        )
    return keyboard_markup
